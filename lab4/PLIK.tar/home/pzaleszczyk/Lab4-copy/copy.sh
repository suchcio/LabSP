#!/bin/bash

mkdir $HOME/Lab4-copy
cp "$HOME/srodowisko/lab4" -r "$HOME/Lab4-copy"
