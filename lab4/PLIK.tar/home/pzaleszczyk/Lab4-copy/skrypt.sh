#!/bin/bash
x=50
napis="treść"
echo "$x $napis"
