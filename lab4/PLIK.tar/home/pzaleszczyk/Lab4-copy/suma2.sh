#!/bin/bash
read x
read y
suma=$[x+y]
echo "$suma"
