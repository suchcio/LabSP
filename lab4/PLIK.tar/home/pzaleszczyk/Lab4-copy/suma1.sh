#!/bin/bash
x=1234
y=4567
suma=$[x+y]
echo "$suma"
