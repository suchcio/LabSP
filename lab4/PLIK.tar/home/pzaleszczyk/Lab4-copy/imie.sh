#!/bin/bash

echo "Paweł Zaleszczyk 45 Czarny"
